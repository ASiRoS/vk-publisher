<?php
/** Debug mode **/
define('DEBUG_MODE', true);

/** Application **/
define('CLIENT_ID', '');
define('CLIENT_SECRET', '');

/** Settings **/
define('REDIRECT_URI', 'https://oauth.vk.com/blank.html');
define('VK_API_VERSION', '3.0');

/** Access token **/
define('ACCESS_TOKEN', 'f9acada93b7bf0193d597af0bd26740da7610436d09a0a14e190bd219ee4567b6ffe10e172b4b22e661a4');

/** Images dir **/
define('IMAGES_DIR', dirname(__FILE__).'/images');

/** Database **/
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', 'pass');
define('DB_NAME', 'vk-publisher');
